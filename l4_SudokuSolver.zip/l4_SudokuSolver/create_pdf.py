from fpdf import FPDF

# Create instance of FPDF class
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)

# Define the content for the PDF document
content = """
Title: Sudoku Solver SAT Approach

1. Introduction
----------------
In this project, we formulate the Sudoku puzzle as a Boolean Satisfiability (SAT) problem by encoding it into Conjunctive Normal Form (CNF). The approach leverages a SAT solver (pycosat) to find a valid solution that meets all Sudoku constraints.

2. Variable Encoding
--------------------
Each cell in the 9x9 Sudoku grid is represented by a set of boolean variables. The proposition "cell (r, c) contains digit d" is mapped to a unique variable using the function:
    varnum(r, c, d) = 81*(r-1) + 9*(c-1) + d
This mapping results in 729 unique variables, where r, c, and d range from 1 to 9.

3. CNF Constraints
------------------
The Sudoku rules are converted into a set of CNF clauses. The key constraints include:

a. Cell Constraints:
   - At Least One: Each cell must contain at least one digit.
     Clause example: [X(r, c, 1), X(r, c, 2), ..., X(r, c, 9)]
   - At Most One: Each cell can contain at most one digit.
     This is enforced by adding pairwise clauses that ensure no two digits can be true simultaneously for the same cell.

b. Row Constraints:
   Each digit must appear exactly once in each row.
   For every row and digit, a clause is added to ensure the digit appears in one of the cells, with additional pairwise constraints to enforce uniqueness.

c. Column Constraints:
   Similarly, each digit must appear exactly once in each column.
   The approach for rows is mirrored for columns.

d. Block Constraints:
   The grid is divided into nine 3x3 subgrids (blocks). For each block and digit:
   - A clause ensures that the digit appears at least once in the block.
   - Pairwise clauses enforce that the digit appears at most once within the block.

4. Initial Setup
----------------
For cells that are pre-filled in the puzzle (the given clues), unit clauses are added to fix the corresponding variable to True. This step ensures that the initial puzzle configuration is preserved in the SAT formulation.

5. SAT Solving and Reconstruction
-----------------------------------
After all constraints and initial conditions are encoded, the CNF formula is passed to the SAT solver (pycosat). If a satisfying assignment is found, the solution is mapped back into the 9x9 grid format.

6. Conclusion
-------------
This approach demonstrates how a combinatorial puzzle like Sudoku can be effectively translated into a SAT problem. By encoding the constraints into CNF and using a SAT solver, we can leverage efficient solving techniques to obtain a solution for even complex puzzles.

"""

# Add the content to the PDF line by line
for line in content.split("\n"):
    pdf.cell(0, 10, txt=line, ln=True)

# Save the PDF to a file
pdf.output("Approach.pdf")
print("PDF 'Approach.pdf' created successfully.")
