import random
from adversary import AdversaryMove, NoviceMove

class YantraCollector:
    def __init__(self, p1_pos, p2_pos, goal_pos, grid_size, player1_strategy):
        """
        Initializes the game with the starting positions of Player 1, Player 2, and the goal position.
        """
        self.p1_pos = p1_pos  
        self.p2_pos = p2_pos
        self.goal_pos = goal_pos
        self.grid_size = grid_size
        self.p1_strat = player1_strategy 
        self.is_p1_turn = True  # Track whose turn it is
        self.path = []

    def is_valid(self, pos):
        """
        Checks if a position is within the game grid boundaries.
        """
        return 0 <= pos[0] < self.grid_size and 0 <= pos[1] < self.grid_size

    def move_player(self, player, direction):
        """
        Moves the specified player in the given direction if valid.
        """
        move_offsets = {'N': (0, 1), 'S': (0, -1), 'E': (1, 0), 'W': (-1, 0)}
        if player == 1:
            new_pos = (self.p1_pos[0] + move_offsets[direction][0],
                       self.p1_pos[1] + move_offsets[direction][1])
            if self.is_valid(new_pos):
                self.p1_pos = new_pos
        else:
            new_pos = (self.p2_pos[0] + move_offsets[direction][0],
                       self.p2_pos[1] + move_offsets[direction][1])
            if self.is_valid(new_pos):
                self.p2_pos = new_pos

    def utility(self, pos):
        """
        Computes a weighted utility score for Player 1 based on Manhattan distances.
        Lower values indicate better outcomes for Player 1.
        """
        p1_dis = abs(pos[0] - self.goal_pos[0]) + abs(pos[1] - self.goal_pos[1])
        p2_dis = abs(self.p2_pos[0] - self.goal_pos[0]) + abs(self.p2_pos[1] - self.goal_pos[1])
        return p1_dis - p2_dis

    def best_player_move(self, pos):
        """
        Determines the best move for Player 1 based on the chosen strategy.
        """
        if self.p1_strat == "random":
            return self.random_move(pos)
        elif self.p1_strat == "minimax_vanilla":
            score, move = self.minimax_vanilla(pos, self.p2_pos, depth=3, max_turn=True)
            return move
        elif self.p1_strat == "minimax":
            score, move = self.minimax(pos, self.p2_pos, depth=3,alpha=float('-inf'), beta=float('inf'), max_turn=True)
            return move
    
    def random_move(self, pos):
        """
        Chooses a random valid move from immediate neighbors.
        """
        move_direction = ['N', 'S', 'E', 'W']
        random.shuffle(move_direction)
        for move in move_direction:
            move_offsets = {'N': (0, 1), 'S': (0, -1), 'E': (1, 0), 'W': (-1, 0)}
            new_pos = (pos[0] + move_offsets[move][0], pos[1] + move_offsets[move][1])
            if self.is_valid(new_pos):
                return move
        return None

    def minimax_vanilla(self, pos, player2, depth, max_turn=True):
        """
        Combined minimax_vanilla function (without alpha-beta pruning) that takes both players' positions.
        
        Parameters:
            pos (tuple): Current position of Player 1.
            pos2 (tuple): Current position of Player 2.
            depth (int): Remaining search depth.
            max_turn (bool): True if it's Player 1's turn (minimizing), False otherwise.
            
        Returns:
            tuple: (score, best_move) where best_move is one of ['N', 'S', 'E', 'W'].
        """
        # Terminal conditions
        if pos == self.goal_pos:
            return float('-inf'), None  # Favorable for P1
        if player2 == self.goal_pos:
            return float('inf'), None   # Unfavorable for P1
        if depth == 0:
            temp_p2 = self.p2_pos
            self.p2_pos = player2
            val = self.utility(pos)
            self.p2_pos = temp_p2
            return val, None

        best_move = None
        move_offsets = {'N': (0, 1), 'S': (0, -1), 'E': (1, 0), 'W': (-1, 0)}
        if max_turn:  # P1's turn (minimizing)
            best_score = float('inf')
            for move in move_offsets:
                # Simulate move for Player 1
                new_player1 = (pos[0] + move_offsets[move][0], pos[1] + move_offsets[move][1])
                if not self.is_valid(new_player1):
                    new_player1 = pos
                # Player 2 mimics the move
                new_player2 = (player2[0] + move_offsets[move][0], player2[1] + move_offsets[move][1])
                if not self.is_valid(new_player2):
                    new_player2 = player2
                score, _ = self.minimax_vanilla(new_player1, new_player2, depth - 1, not max_turn)
                if score < best_score:
                    best_score = score
                    best_move = move
            return best_score, best_move
        
        else:  # P2's turn (maximizing)
            best_score = float('-inf')
            for move in move_offsets:
                # Simulate move for Player 2
                new_player2 = (player2[0] + move_offsets[move][0], player2[1] + move_offsets[move][1])
                if not self.is_valid(new_player2):
                    new_player2 = player2
                # Player 1 mimics the move
                new_player1 = (pos[0] + move_offsets[move][0], pos[1] + move_offsets[move][1])
                if not self.is_valid(new_player1):
                    new_player1 = pos
                score, _ = self.minimax_vanilla(new_player1, new_player2, depth - 1, not max_turn)
                if score > best_score:
                    best_score = score
                    best_move = move
            return best_score, best_move

    def minimax(self, pos, player2, depth, alpha=float('-inf'), beta=float('inf'), max_turn=True):
        """
        Combined minimax function using alpha-beta pruning that takes both players' positions.
        
        Parameters:
            pos (tuple): Current position of Player 1.
            pos2 (tuple): Current position of Player 2.
            depth (int): Remaining search depth.
            alpha (float): Alpha value for pruning.
            beta (float): Beta value for pruning.
            max_turn (bool): True if it's Player 1's turn (minimizing), False otherwise.
            
        Returns:
            tuple: (score, best_move) where best_move is one of ['N', 'S', 'E', 'W'].
        """
        if pos == self.goal_pos:
            return -1000, None
        if player2 == self.goal_pos:
            return 1000, None
        if depth == 0:
            temp_p2 = self.p2_pos
            self.p2_pos = player2
            val = self.utility(pos)
            self.p2_pos = temp_p2
            return val, None

        best_move = None
        move_offsets = {'N': (0, 1), 'S': (0, -1), 'E': (1, 0), 'W': (-1, 0)}
        if max_turn:  # P1's turn (minimizing)
            best_score = float('inf')
            for move in move_offsets:
                new_player1 = (pos[0] + move_offsets[move][0], pos[1] + move_offsets[move][1])
                if not self.is_valid(new_player1):
                    new_player1 = pos
                new_player2 = (player2[0] + move_offsets[move][0], player2[1] + move_offsets[move][1])
                if not self.is_valid(new_player2):
                    new_player2 = player2
                score, _ = self.minimax(new_player1, new_player2, depth - 1, alpha, beta, not max_turn)
                if score < best_score:
                    best_score = score
                    best_move = move
                beta = min(beta, best_score)
                if beta <= alpha:
                    break
            return best_score, best_move
        else:  # P2's turn (maximizing)
            best_score = float('-inf')
            for move in ['N', 'S', 'E', 'W']:
                new_player2 = (player2[0] + move_offsets[move][0], player2[1] + move_offsets[move][1])
                if not self.is_valid(new_player2):
                    new_player2 = player2
                new_player1 = (pos[0] + move_offsets[move][0], pos[1] + move_offsets[move][1])
                if not self.is_valid(new_player1):
                    new_player1 = pos
                score, _ = self.minimax(new_player1, new_player2, depth - 1, alpha, beta, not max_turn)
                if score > best_score:
                    best_score = score
                    best_move = move
                alpha = max(alpha, best_score)
                if beta <= alpha:
                    break
            return best_score, best_move

    def play_game(self):
        """
        Runs the game loop until a player wins or a draw occurs.
        """
        seen_positions = set()
        while True:
            state = (self.p1_pos, self.p2_pos)
            if self.p1_pos == self.p2_pos or state in seen_positions:
                return "draw"
            seen_positions.add(state)
            if self.is_p1_turn:
                best_move = self.best_player_move(self.p1_pos)
                self.path.append(best_move)
                self.move_player(1, best_move)
                self.move_player(2, best_move)  # P2 mimics P1
            else:
                best_move = AdversaryMove(self.p2_pos, self)
                self.move_player(2, best_move)
                self.move_player(1, best_move)  # P1 mimics P2
            if self.p1_pos == self.goal_pos:
                return "P1"
            elif self.p2_pos == self.goal_pos:
                return "P2"
            self.is_p1_turn = not self.is_p1_turn

    def play_game_novice(self):
        """
        Runs the game loop where Player 2 follows the novice strategy.
        """
        seen_positions = set()
        while True:
            state = (self.p1_pos, self.p2_pos)
            if self.p1_pos == self.p2_pos or state in seen_positions:
                return "draw"
            seen_positions.add(state)
            if self.is_p1_turn:
                best_move = self.best_player_move(self.p1_pos)
                self.path.append(best_move)
                self.move_player(1, best_move)
                self.move_player(2, best_move)
            else:
                best_move = NoviceMove(self.p2_pos, self)
                self.move_player(2, best_move)
                self.move_player(1, best_move)
            if self.p1_pos == self.goal_pos:
                return "P1"
            elif self.p2_pos == self.goal_pos:
                return "P2"
            self.is_p1_turn = not self.is_p1_turn
