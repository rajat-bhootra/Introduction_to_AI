def selection_sort(lst):
    for i in range(len(lst)):
        min_index = i
        for j in range(i+1,len(lst)):
            if lst[j][0] < lst[min_index][0] :
                min_index = j
        (lst[i],lst[min_index]) = (lst[min_index],lst[i]) 
 
def insertionSort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and key[0] < arr[j][0]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key        
lst = [[4,(5,1)],[1,(3,3)],[3,(2,6)],[2,(4,2)]]
print(lst)
insertionSort(lst)
print(lst)        

position = lst[1][1]
print(position[1])