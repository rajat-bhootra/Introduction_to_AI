import heapq

# Constant costs for yantra and exit cells
YANTRA_COST = 0
EXIT_COST = 0
TRAP_COST = 99999

class YantraCollector:
    def __init__(self, grid):
        self.grid = grid
        self.n = len(grid)
        self.start = self.find_position('P')
        self.exit = None
        self.yantras = self.find_all_yantras()
        self.revealed_yantra = self.find_position('Y1')
        self.collected_yantras = 0
        self.cost_map = self.initialize_cost_map()
    
    def initialize_cost_map(self):
        cost_map = {}
        for i in range(self.n):
            for j in range(self.n):
                cell_value = self.grid[i][j]
                if isinstance(cell_value, int):  
                    cost_map[(i, j)] = cell_value
                elif cell_value in ['P', 'E']:  
                    cost_map[(i, j)] = 0
                elif isinstance(cell_value, str) and cell_value.startswith('Y'):  
                    cost_map[(i, j)] = YANTRA_COST
                elif cell_value == 'T':
                    cost_map[(i, j)] = TRAP_COST
        return cost_map
    
    def find_position(self, symbol):
        for i in range(self.n):
            for j in range(self.n):
                if self.grid[i][j] == symbol:
                    return (i, j)
        return None

    def find_all_yantras(self):
        positions = {}
        for i in range(self.n):
            for j in range(self.n):
                if isinstance(self.grid[i][j], str) and self.grid[i][j].startswith('Y'):
                    positions[int(self.grid[i][j][1:])] = (i, j)
                elif self.grid[i][j] == 'E':
                    self.exit = (i, j)
        return positions

    def reveal_next_yantra_or_exit(self):
        self.collected_yantras += 1
        if self.collected_yantras + 1 in self.yantras:
            self.revealed_yantra = self.yantras[self.collected_yantras + 1]
        elif self.collected_yantras == len(self.yantras):
            self.revealed_yantra = self.exit
        return self.revealed_yantra

    def goal_test(self, position):
        return position == self.revealed_yantra

    def get_neighbors(self, position):
        neighbors = []
        directions = [(-1,0), (0,1), (1,0), (0,-1)]
        x, y = position
        for dx, dy in directions: 
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.n and 0 <= ny < self.n and self.grid[nx][ny] != '#' and self.grid[nx][ny] != 'T':
                neighbors.append((nx, ny))
        return neighbors
    
    def ucs(self):
        frontier = [[0, self.start]]
        explored = []
        
        while frontier:
            frontier.sort()
            cost, current = frontier.pop(0)
            if current in explored:
                continue
            explored.append(current)
            if self.goal_test(current):
                print(len(frontier))
                return len(frontier), len(explored), cost
            for neighbor in self.get_neighbors(current):
                frontier.append([cost + self.cost_map[neighbor], neighbor])
        return None

    def heuristic(self, position):
        return len(self.yantras) - self.collected_yantras

    def gbfs(self):
        frontier = [[self.heuristic(self.start), self.start]]
        explored = []
        
        while frontier:
            frontier.sort()
            _, current = frontier.pop(0)
            if current in explored:
                continue
            explored.append(current)
            if self.goal_test(current):
                return len(frontier), len(explored), self.cost_map[current]
            for neighbor in self.get_neighbors(current):
                frontier.append([self.heuristic(neighbor), neighbor])
        return None

    def a_star(self):
        frontier = [[self.heuristic(self.start), 0, self.start]]
        explored = []
        
        while frontier:
            frontier.sort()
            _, cost, current = frontier.pop(0)
            if current in explored:
                continue
            explored.append(current)
            if self.goal_test(current):
                return len(frontier), len(explored), cost
            for neighbor in self.get_neighbors(current):
                new_cost = cost + self.cost_map[neighbor]
                frontier.append([new_cost + self.heuristic(neighbor), new_cost, neighbor])
        return None
    
    def solve(self, strategy):
        
        total_frontier_nodes = 0
        total_explored_nodes = 0
        total_cost = 0
        while self.revealed_yantra:
              if strategy == "UCS":
                 self.start = self.revealed_yantra
                 self.reveal_next_yantra_or_exit()   
                 self.start = self.revealed_yantra
                 self.reveal_next_yantra_or_exit() 
                 frontier, explored, totalCost = self.ucs()
                 total_frontier_nodes += frontier
                 total_explored_nodes += explored
                 total_cost += totalCost
                 break
              elif strategy == "GBFS":
                  return self.gbfs()
              elif strategy == "A*":
                  return self.a_star()
              else:
                  return None
        
        return total_frontier_nodes, total_explored_nodes, total_cost
if __name__ == "__main__":
    grid = [
        ['P', 2, '#', 5, 'Y2'],
        ['T', 2, 3, '#', 1],
        [0, 7, 'Y1', 4, 2],
        ['#', 'T', 2, 1, 3],
        [1, 3, 0, 2, 'E']
    ]

    game = YantraCollector(grid)
    strategy = "UCS"  # or "UCS" or "GBFS"
    result = game.solve(strategy)
    
    if result:
        total_frontier_nodes, total_explored_nodes, total_cost = result
        print("Total Frontier Nodes:", total_frontier_nodes)
        print("Total Explored Nodes:", total_explored_nodes)
        print("Total Cost:", total_cost)
    else:
        print("No solution found.")
        
        
